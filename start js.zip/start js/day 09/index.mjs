function calculate(a,b) {
return("sum of",a+b )
}
console.log(calculate(25,50))