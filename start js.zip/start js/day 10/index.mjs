function averageNum(a,b,c) {
    let add = a + b + c
    let divide = add/3
    return(divide)
    
}
console.log(averageNum(20,30,60))