let f = prompt ("")
let s = prompt ("")
if (f>s) {
    alert ("First number is greater than second number")
} else if (f==s) {
    alert ("both number are equal+")

}   else {
     alert ("smaller than")
   }