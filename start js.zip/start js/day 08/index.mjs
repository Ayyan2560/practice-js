function checkage(age) {
 if (age >= 18) {
   return("adult");
 } else {
  return ("MINOR");
 }
    
}
console.log(checkage(10));